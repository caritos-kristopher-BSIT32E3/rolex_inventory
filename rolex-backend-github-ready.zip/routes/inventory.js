
const express = require('express');
const router = express.Router();
const db = require('../db');

router.get('/', async (req, res) => {
  try {
    const result = await db.query('SELECT * FROM watches');
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.post('/', async (req, res) => {
  const { model, price, stock, description } = req.body;
  try {
    await db.query(
      'INSERT INTO watches (model, price, stock, description) VALUES ($1, $2, $3, $4)',
      [model, price, stock, description]
    );
    res.status(201).json({ message: 'Watch added successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', async (req, res) => {
  const { id } = req.params;
  const { model, price, stock, description } = req.body;
  try {
    await db.query(
      'UPDATE watches SET model = $1, price = $2, stock = $3, description = $4 WHERE id = $5',
      [model, price, stock, description, id]
    );
    res.json({ message: 'Watch updated successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM watches WHERE id = $1', [id]);
    res.json({ message: 'Watch deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;

const express = require('express');
const cors = require('cors');
const app = express();
require('dotenv').config();

const inventoryRoutes = require('./routes/inventory');
const authRoutes = require('./routes/auth');

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/inventory', inventoryRoutes);

app.listen(process.env.PORT, () => {
  console.log(`Server running on http://localhost:${process.env.PORT}`);
});

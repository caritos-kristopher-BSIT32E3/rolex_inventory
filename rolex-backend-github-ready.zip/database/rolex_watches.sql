
CREATE TABLE IF NOT EXISTS rolex_watches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model VARCHAR(100),
    collection VARCHAR(100),
    material VARCHAR(100),
    dial_color VARCHAR(50),
    bracelet_type VARCHAR(100),
    price_usd DECIMAL(10,2),
    release_year YEAR,
    description TEXT,
    image_url VARCHAR(255)
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Submariner Date',
    'Submariner',
    'Oystersteel',
    'Black',
    'Oyster',
    9950.0,
    2020,
    'Iconic diving watch with black dial and Cerachrom bezel.',
    'images/submariner.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Daytona Cosmograph',
    'Daytona',
    'Yellow Gold',
    'Champagne',
    'Oysterflex',
    28750.0,
    2021,
    'Luxury chronograph designed for endurance racing.',
    'images/daytona.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'GMT-Master II',
    'GMT-Master',
    'Everose Gold',
    'Black',
    'Oyster',
    39800.0,
    2022,
    'Dual time zone watch with bidirectional bezel.',
    'images/gmt-master.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Datejust 41',
    'Datejust',
    'White Rolesor',
    'Blue',
    'Jubilee',
    7950.0,
    2019,
    'Elegant classic watch with fluted bezel and cyclops lens.',
    'images/datejust.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Explorer II',
    'Explorer',
    'Oystersteel',
    'White',
    'Oyster',
    9150.0,
    2020,
    'Adventure-ready timepiece with 24-hour bezel.',
    'images/explorer.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Yacht-Master 40',
    'Yacht-Master',
    'Rolesium',
    'Rhodium',
    'Oysterflex',
    14250.0,
    2021,
    'Nautical watch with platinum bezel and blue seconds hand.',
    'images/yacht-master.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Oyster Perpetual 36',
    'Oyster Perpetual',
    'Oystersteel',
    'Green',
    'Oyster',
    6100.0,
    2023,
    'Vibrant, colorful dial with classic Rolex elegance.',
    'images/oyster-perpetual.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Sky-Dweller',
    'Sky-Dweller',
    'Yellow Rolesor',
    'White',
    'Oyster',
    15500.0,
    2021,
    'Annual calendar and dual time zone for frequent travelers.',
    'images/sky-dweller.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Milgauss',
    'Milgauss',
    'Oystersteel',
    'Z-Blue',
    'Oyster',
    9200.0,
    2018,
    'Anti-magnetic watch with lightning bolt seconds hand.',
    'images/milgauss.jpg'
);

INSERT INTO rolex_watches (model, collection, material, dial_color, bracelet_type, price_usd, release_year, description, image_url)
VALUES (
    'Cellini Moonphase',
    'Cellini',
    'Everose Gold',
    'White',
    'Leather',
    26500.0,
    2022,
    'Elegant dress watch with moonphase complication.',
    'images/cellini.jpg'
);

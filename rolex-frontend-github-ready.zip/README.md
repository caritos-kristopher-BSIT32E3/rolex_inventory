# Rolex Inventory UI

React + Vite app for displaying Rolex watches.

## 📦 Installation

```bash
npm install
```

## 🚀 Development

```bash
npm start
```

## 🔗 API Configuration

Set your backend API URL in a `.env` file:

```env
VITE_API_URL=http://localhost:5000
```

## 🛠 Build for Production

```bash
npm run build
```
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useInventory } from "./InventoryContext";

export default function Dashboard() {
  const { items, addItem, deleteItem, updateItem } = useInventory();
  const [form, setForm] = useState({ name: "", quantity: "", status: "In Stock" });
  const [editingId, setEditingId] = useState(null);
  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem("darkMode") === "true";
  });
  const [iconRotate, setIconRotate] = useState(false);
  const [logoutAnimate, setLogoutAnimate] = useState(false);
  const navigate = useNavigate();

  // 🔃 SORTING STATE
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "ascending" });

  const sortedItems = React.useMemo(() => {
    let sortableItems = [...items];
    if (sortConfig.key !== null) {
      sortableItems.sort((a, b) => {
        const aVal = a[sortConfig.key].toString().toLowerCase();
        const bVal = b[sortConfig.key].toString().toLowerCase();
        if (aVal < bVal) return sortConfig.direction === "ascending" ? -1 : 1;
        if (aVal > bVal) return sortConfig.direction === "ascending" ? 1 : -1;
        return 0;
      });
    }
    return sortableItems;
  }, [items, sortConfig]);

  const requestSort = (key) => {
    let direction = "ascending";
    if (sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending";
    }
    setSortConfig({ key, direction });
  };

  useEffect(() => {
    localStorage.setItem("darkMode", darkMode);
  }, [darkMode]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId) {
      updateItem({ ...form, id: editingId });
      setEditingId(null);
    } else {
      const newItem = { id: Date.now(), ...form };
      addItem(newItem);
    }
    setForm({ name: "", quantity: "", status: "In Stock" });
  };

  const handleEdit = (item) => {
    setForm({ name: item.name, quantity: item.quantity, status: item.status });
    setEditingId(item.id);
  };

  const handleLogout = () => {
    setLogoutAnimate(true);
    setTimeout(() => {
      localStorage.removeItem("auth");
      navigate("/loginpage");
    }, 300);
  };

  const theme = {
    background: darkMode ? "#0f0f0f" : "#f4f4f4",
    card: darkMode ? "#1a1a1a" : "#ffffff",
    text: darkMode ? "#ffffff" : "#000000",
    border: darkMode ? "#333" : "#ddd",
    primary: "#d4af37",
    font: "'Lato', sans-serif",
    titleFont: "'Playfair Display', serif",
  };

  const toggleMode = () => {
    setIconRotate(true);
    setDarkMode(!darkMode);
    setTimeout(() => setIconRotate(false), 300);
  };

  return (
    <div
      style={{
        backgroundColor: theme.background,
        color: theme.text,
        minHeight: "100vh",
        padding: "2rem",
        fontFamily: theme.font,
        transition: "all 0.3s ease-in-out",
      }}
    >
      {/* Header */}
      <header
        className="d-flex justify-content-between align-items-center p-4 rounded shadow mb-4"
        style={{
          backgroundColor: theme.card,
          border: `1px solid ${theme.border}`,
        }}
      >
        <div className="d-flex align-items-center gap-3">
          <img src="/logo.png" alt="Logo" style={{ height: "50px" }} />
          <h1 style={{ fontFamily: theme.titleFont, fontSize: "28px", color: theme.primary }}>
          Inventory Dashboard
          </h1>
        </div>
        <div className="d-flex gap-3 align-items-center">
          <button
            onClick={toggleMode}
            className="btn d-flex align-items-center gap-2"
            style={{
              backgroundColor: darkMode ? theme.primary : theme.card,
              color: darkMode ? "#000" : theme.text,
              fontWeight: "600",
              borderRadius: "30px",
              padding: "8px 20px",
              fontSize: "14px",
              border: `1px solid ${theme.border}`,
              fontFamily: theme.font,
              boxShadow: darkMode ? "0 0 8px rgba(212, 175, 55, 0.2)" : "0 0 4px rgba(0,0,0,0.1)",
              transition: "all 0.3s ease-in-out",
            }}
            onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = darkMode ? "#f5d76e" : "#f1f1f1")}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = darkMode ? theme.primary : theme.card)}
          >
            <span
              style={{
                display: "inline-block",
                transition: "transform 0.3s ease-in-out",
                transform: iconRotate ? "rotate(360deg)" : "rotate(0deg)",
              }}
            >
              {darkMode ? "🌞" : "🌙"}
            </span>
            {darkMode ? "Light Mode" : "Dark Mode"}
          </button>
          <button
            onClick={handleLogout}
            className="btn"
            style={{
              background: theme.primary,
              color: "#000",
              fontWeight: "700",
              borderRadius: "50px",
              padding: "10px 24px",
              fontSize: "14px",
              border: "none",
              fontFamily: theme.font,
              boxShadow: darkMode ? "0 0 12px rgba(212, 175, 55, 0.3)" : "0 0 6px rgba(0,0,0,0.1)",
              transition: "transform 0.3s ease-in-out",
              transform: logoutAnimate ? "scale(1.1) rotate(-5deg)" : "scale(1) rotate(0deg)",
            }}
          >
            Logout
          </button>
        </div>
      </header>

      {/* Form */}
      <form
        onSubmit={handleSubmit}
        className="p-4 rounded shadow mb-5"
        style={{
          backgroundColor: theme.card,
          border: `1px solid ${theme.border}`,
          transition: "all 0.3s ease-in-out",
        }}
      >
        <table className="table table-bordered" style={{ color: theme.text }}>
          <thead>
            <tr>
              <th>Item Name</th>
              <th>Quantity</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="Item Name"
                  className="form-control"
                  style={{
                    borderRadius: "8px",
                    padding: "8px",
                    backgroundColor: theme.background,
                    border: `1px solid ${theme.border}`,
                    color: theme.text,
                  }}
                  required
                />
              </td>
              <td>
                <input
                  name="quantity"
                  value={form.quantity}
                  onChange={handleChange}
                  type="number"
                  placeholder="Quantity"
                  className="form-control"
                  style={{
                    borderRadius: "8px",
                    padding: "8px",
                    backgroundColor: theme.background,
                    border: `1px solid ${theme.border}`,
                    color: theme.text,
                  }}
                  required
                />
              </td>
              <td>
                <select
                  name="status"
                  value={form.status}
                  onChange={handleChange}
                  className="form-select"
                  style={{
                    borderRadius: "8px",
                    padding: "8px",
                    backgroundColor: theme.background,
                    border: `1px solid ${theme.border}`,
                    color: theme.text,
                  }}
                >
                  <option>In Stock</option>
                  <option>Low Stock</option>
                  <option>Out of Stock</option>
                </select>
              </td>
              <td>
                <button
                  type="submit"
                  className="btn"
                  style={{
                    background: editingId ? "#b08d57" : theme.primary,
                    color: "#000",
                    fontWeight: "700",
                    borderRadius: "50px",
                    padding: "8px 20px",
                    border: "none",
                    fontFamily: theme.font,
                    boxShadow: darkMode ? "0 0 10px rgba(212, 175, 55, 0.3)" : "0 0 4px rgba(0,0,0,0.1)",
                  }}
                >
                  {editingId ? "Update" : "Add"}
                </button>
              </td>
            </tr>
          </tbody>
        </table>
      </form>

      {/* Item Table */}
      <div
        className="p-4 rounded shadow"
        style={{
          backgroundColor: theme.card,
          border: `1px solid ${theme.border}`,
          transition: "all 0.3s ease-in-out",
        }}
      >
        <table className="table text-center align-middle" style={{ color: theme.text }}>
          <thead style={{ backgroundColor: "#2a2a2a", color: theme.primary }}>
            <tr>
              <th>#</th>
              <th style={{ cursor: "pointer" }} onClick={() => requestSort("name")}>
                Item Name 🔃 {sortConfig.key === "name" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}
              </th>
              <th style={{ cursor: "pointer" }} onClick={() => requestSort("quantity")}>
                Quantity 🔃 {sortConfig.key === "quantity" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}
              </th>
              <th style={{ cursor: "pointer" }} onClick={() => requestSort("status")}>
                Status 🔃 {sortConfig.key === "status" ? (sortConfig.direction === "ascending" ? "↑" : "↓") : ""}
              </th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {sortedItems.map((item, index) => (
              <tr
                key={item.id}
                style={{
                  transition: "background 0.3s ease",
                  backgroundColor: index % 2 === 0 ? theme.card : darkMode ? "#1f1f1f" : "#f9f9f9",
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = "#2a2a2a")}
                onMouseLeave={(e) =>
                  (e.currentTarget.style.backgroundColor =
                    index % 2 === 0 ? theme.card : darkMode ? "#1f1f1f" : "#f9f9f9")
                }
              >
                <td>{index + 1}</td>
                <td>{item.name}</td>
                <td>{item.quantity}</td>
                <td>{item.status}</td>
                <td>
                  <div className="d-flex justify-content-center gap-2">
                    <button
                      onClick={() => handleEdit(item)}
                      className="btn btn-sm"
                      style={{
                        background: "#3e8e41",
                        color: "#fff",
                        borderRadius: "30px",
                        padding: "6px 16px",
                        fontWeight: "600",
                        fontFamily: theme.font,
                        transition: "all 0.3s ease",
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => deleteItem(item.id)}
                      className="btn btn-sm"
                      style={{
                        background: "#a93226",
                        color: "#fff",
                        borderRadius: "30px",
                        padding: "6px 16px",
                        fontWeight: "600",
                        fontFamily: theme.font,
                        transition: "all 0.3s ease",
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Footer */}
      <footer
        className="text-center mt-5"
        style={{
          color: darkMode ? "#888" : "#555",
          fontSize: "14px",
          fontStyle: "italic",
          borderTop: `1px solid ${theme.border}`,
          paddingTop: "2rem",
        }}
      >
        <p>© 2025 Rolex Inventory System.</p>
      </footer>
    </div>
  );
}

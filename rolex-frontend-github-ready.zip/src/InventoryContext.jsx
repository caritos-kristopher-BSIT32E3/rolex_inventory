import React, { createContext, useContext, useState } from "react";

const InventoryContext = createContext();

export const useInventory = () => useContext(InventoryContext);

export function InventoryProvider({ children }) {
  const [items, setItems] = useState([
    { id: 1, name: "Luxury Watch", quantity: 5, status: "In Stock" },
    { id: 2, name: "Gold Bracelet", quantity: 2, status: "Low Stock" }
  ]);

  const addItem = (item) => {
    setItems([...items, { ...item, id: Date.now() }]);
  };

  const deleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  const updateItem = (updatedItem) => {
    setItems(items.map(item => (item.id === updatedItem.id ? updatedItem : item)));
  };

  return (
    <InventoryContext.Provider value={{ items, addItem, deleteItem, updateItem }}>
      {children}
    </InventoryContext.Provider>
  );
}

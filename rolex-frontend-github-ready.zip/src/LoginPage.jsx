import React from "react";
import { useNavigate } from "react-router-dom";

export default function LoginPage() {
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    localStorage.setItem("auth", "true");
    navigate("/dashboard");
  };

  return (
    <div className="h-screen w-full bg-[#0a0a0a] flex items-center justify-center relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-[#003c1c] to-black opacity-40"></div>

      {/* Glass Card */}
      <form
        onSubmit={handleLogin}
        className="relative z-10 backdrop-blur-md bg-white/10 border border-[#c9b037]/30 text-white p-10 rounded-2xl shadow-lg w-[380px]"
      >
        <div className="flex flex-col items-center mb-8">
          <img
            src="/logo.png"
            alt="Rolex Logo"
            className="w-16 h-16 mb-4"
            style={{ filter: "drop-shadow(0 0 6px #c9b037)" }}
          />
          <h2 className="text-3xl font-semibold tracking-wide text-[#c9b037] font-serif">
            Rolex Inventory
          </h2>
        </div>

        <input
          type="text"
          placeholder="Username"
          className="w-full mb-4 p-3 bg-black/30 text-white border border-gray-500 rounded focus:outline-none focus:ring-2 focus:ring-[#c9b037]"
          required
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full mb-6 p-3 bg-black/30 text-white border border-gray-500 rounded focus:outline-none focus:ring-2 focus:ring-[#c9b037]"
          required
        />

        <button
          type="submit"
          className="w-full bg-[#c9b037] text-black py-2 rounded-md font-bold hover:bg-[#b89f2e] transition-all duration-300 shadow-md"
        >
          Login
        </button>
      </form>
    </div>
  );
}
